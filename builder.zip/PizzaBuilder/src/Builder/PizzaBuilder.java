package Builder;

import Product.Pizza;

public abstract class PizzaBuilder {
	protected Pizza pizza;
	
	public Pizza getPizza(){
		return pizza;
	}
	
	public void CreateNewPizzaProduct(){
		pizza = new Pizza();
	}
	
	public abstract void buildPedacos();
	public abstract void buildSabor();
	
}
