package ConcreteBuilder;

import Builder.PizzaBuilder;

public class PizzaCalabresa extends PizzaBuilder{
	
	@Override
	public void buildPedacos(){
		pizza.setPedacos(8);
		System.out.println("Construindo pedacos da pizza");
	}
	
	@Override
	public void buildSabor(){
		pizza.setSabor("Calabresa");
		System.out.println("Construindo sabor da pizza");
	}

}
