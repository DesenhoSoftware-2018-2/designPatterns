package ConcreteBuilder;

import Builder.PizzaBuilder;

public class PizzaFrango extends PizzaBuilder{
	
	@Override
	public void buildPedacos(){
		pizza.setPedacos(10);
		System.out.println("Construindo pedacos da pizza");
	}
	
	@Override
	public void buildSabor(){
		pizza.setSabor("Frango");
		System.out.println("Construindo sabor da pizza");
	}

}
