package Director;

import Builder.PizzaBuilder;
import Product.Pizza;

public class Garcom {
	protected PizzaBuilder pizzaBuilder;
	
	public void setPizzaBuilder(PizzaBuilder pizzaBuilder){
		this.pizzaBuilder = pizzaBuilder; 
	}
	
	public Pizza getPizza(){
		return pizzaBuilder.getPizza();
	}
	
	public void buildPizza(){
		pizzaBuilder.CreateNewPizzaProduct();
		pizzaBuilder.buildPedacos();
		pizzaBuilder.buildSabor();
	}
	

}
