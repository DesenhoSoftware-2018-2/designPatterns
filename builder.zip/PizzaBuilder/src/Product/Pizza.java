package Product;

public class Pizza {
	private int pedacos;
	private String sabor;
	
	public void setPedacos(int pedacos) {
		this.pedacos = pedacos;
	}
	
	public void setSabor(String sabor){
		this.sabor = sabor;
	}
	
	public int getPedacos(){
		return pedacos;
	}
	
	public String getSabor(){
		return sabor;
	}
	
}
