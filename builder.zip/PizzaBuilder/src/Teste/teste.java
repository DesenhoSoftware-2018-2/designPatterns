package Teste;

import Director.Garcom;
import Builder.PizzaBuilder;
import Product.Pizza;
import ConcreteBuilder.PizzaFrango;
import ConcreteBuilder.PizzaCalabresa;


public class teste {

	public static void main(String[] args) {
		Garcom garcom = new Garcom();
		PizzaBuilder pizzaFrango = new PizzaFrango();
		PizzaBuilder pizzaCalabresa = new PizzaCalabresa();
		
		garcom.setPizzaBuilder(pizzaCalabresa);
		garcom.buildPizza();
		Pizza pizza = garcom.getPizza();
		System.out.print("Pedacos:" + pizza.getPedacos() + "\nSabor:" + pizza.getSabor());
		
		
	}

}
