package Client;

import Composite.Hamburguer;
import Leafs.*;
import Component.Comida;

public class Teste {
	public static void main(String[] args) {
		Comida comida01 = new Pao("Pao");
		Comida comida02 = new Ovo("Ovo");
		Comida comida03 = new Carne("Carne");
		Comida comida04 = new Salada("Salada");
		
		Hamburguer hamburguer = new Hamburguer();
		hamburguer.add(comida01);
		hamburguer.add(comida02);
		hamburguer.MontarSanduiche();
	}
}
