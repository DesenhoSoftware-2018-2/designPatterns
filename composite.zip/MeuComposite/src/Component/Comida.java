package Component;

public interface Comida {
	public void MontarSanduiche();
}
