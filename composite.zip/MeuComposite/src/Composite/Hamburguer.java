package Composite;
import java.util.ArrayList;
import java.util.List;

import Component.Comida;

public class Hamburguer implements Comida{
	private List <Comida> comidas = new ArrayList <Comida>();
	
	public void add(Comida comida){
		this.comidas.add(comida);		
	}
	
	public void remove(Comida comida){
		this.comidas.remove(comida); 
	}
	
	@Override
	public void MontarSanduiche(){
		for(Comida comida : this.comidas){
			comida.MontarSanduiche();
		}
	}
	
}
