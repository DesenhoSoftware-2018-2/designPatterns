package Leafs;

import Component.Comida;

public class Carne implements Comida{

	private String comida;
	
	public Carne(String comida){
		this.comida = comida;		
	}
	
	@Override
	public void MontarSanduiche(){
		System.out.println("Adicionando carne");
	}
}
