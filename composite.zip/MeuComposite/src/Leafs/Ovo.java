package Leafs;

import Component.Comida;

public class Ovo implements Comida{
	private String comida;
	
	public Ovo(String comida){
		this.comida = comida;		
	}
	
	
	@Override
	public void MontarSanduiche(){
		System.out.println("Adicionando ovo");
	}

}
