package Leafs;

import Component.Comida;

public class Pao implements Comida{
	
	private String comida;
	
	public Pao(String comida){
		this.comida = comida;		
	}
	
	@Override
	public void MontarSanduiche(){
		System.out.println("Adicionando pao");
	}

}
