package Leafs;

import Component.Comida;

public class Salada implements Comida{
	
	private String comida;
	
	public Salada(String comida){
		this.comida = comida;		
	}
	
	@Override
	public void MontarSanduiche(){
		System.out.println("Adicionando Salada");		
	}

}
