package Client;

import Strategy.Imposto;
import Context.CalculadorDeImpostos;
import ConcreteStrategy.Icms;
import ConcreteStrategy.Ipi;

public class Teste {
	public static void main(String[] args){
		CalculadorDeImpostos calculador = new CalculadorDeImpostos();
		Icms icms = new Icms(100);
		Ipi ipi= new Ipi(100);
		
		System.out.println(calculador.calcular(icms));
		System.out.println(calculador.calcular(ipi));
	}

}
