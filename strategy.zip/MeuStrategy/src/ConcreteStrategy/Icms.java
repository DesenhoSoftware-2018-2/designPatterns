package ConcreteStrategy;

import Strategy.Imposto;

public class Icms implements Imposto{
	
	private double valor;
	
	public Icms(double valor){
		this.valor = valor;		
	}
	
	@Override
	public double calcular(){
		System.out.println("Calculando ICMS");
		return this.valor * 0.10;
	}

}
