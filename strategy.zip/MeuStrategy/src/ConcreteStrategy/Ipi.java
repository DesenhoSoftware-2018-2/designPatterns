package ConcreteStrategy;

import Strategy.Imposto;

public class Ipi implements Imposto{
	private double valor;
	
	public Ipi(double valor){
		this.valor = valor;		
	}
	
	@Override
	public double calcular(){
		System.out.println("Calculando IPI");
		return this.valor * 0.15;
	}
	

}
