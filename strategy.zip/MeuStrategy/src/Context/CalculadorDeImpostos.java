package Context;

import Strategy.Imposto;

public class CalculadorDeImpostos {
	public double calcular(Imposto imposto){
		return imposto.calcular();
	}
}
