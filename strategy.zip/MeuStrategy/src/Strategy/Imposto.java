package Strategy;

public interface Imposto {
	double calcular();
}
